from fastapi import FastAPI, Request, HTTPException
import redis.asyncio as redis
import time

app = FastAPI(title="Biblioteca Municipal - Servicios de Usuario")

redis_client = None

@app.on_event("startup")
async def startup_event():
    global redis_client
    redis_client = redis.from_url("redis://localhost", decode_responses=True)

metrics = {
    "db_hits": 0,
    "cache_hits": 0,
    "total_requests": 0,
    "response_times": []
}

rate_limit_storage = {}
RATE_LIMIT = 10 
TIME_WINDOW = 60  

@app.middleware("http")
async def rate_limiter(request: Request, call_next):
    client_ip = request.client.host
    now = time.time()

    if client_ip not in rate_limit_storage:
        rate_limit_storage[client_ip] = []

    rate_limit_storage[client_ip] = [
        t for t in rate_limit_storage[client_ip] if now - t < TIME_WINDOW
    ]

    if len(rate_limit_storage[client_ip]) >= RATE_LIMIT:
        raise HTTPException(status_code=429, detail="Demasiadas peticiones, intente más tarde")

    rate_limit_storage[client_ip].append(now)

    start = time.time()
    response = await call_next(request)
    end = time.time()

    metrics["total_requests"] += 1
    metrics["response_times"].append(end - start)

    return response

@app.get("/")
async def root():
    return {"message": "API Biblioteca Municipal funcionando"}

@app.get("/libro/{libro_id}")
async def get_libro(libro_id: int):
    cache_key = f"libro:{libro_id}"

    if await redis_client.exists(cache_key):
        metrics["cache_hits"] += 1
        return {"source": "cache", "data": await redis_client.get(cache_key)}

 
    libro_data = f"Libro {libro_id}: Don Quijote de la Mancha"
    await redis_client.set(cache_key, libro_data, ex=120)  # expira en 2 min

    metrics["db_hits"] += 1
    return {"source": "db", "data": libro_data}

@app.get("/usuario/{usuario_id}/prestamos")
async def get_prestamos_usuario(usuario_id: int):
    cache_key = f"usuario:{usuario_id}:prestamos"

    if await redis_client.exists(cache_key):
        metrics["cache_hits"] += 1
        return {"source": "cache", "data": await redis_client.get(cache_key)}

    prestamos = f"Usuario {usuario_id} tiene 3 préstamos activos"
    await redis_client.set(cache_key, prestamos, ex=180)  # expira en 3 min

    metrics["db_hits"] += 1
    return {"source": "db", "data": prestamos}

@app.get("/metrics")
async def get_metrics():
    avg_response = (
        sum(metrics["response_times"]) / len(metrics["response_times"])
        if metrics["response_times"] else 0
    )
    return {
        "total_requests": metrics["total_requests"],
        "db_hits": metrics["db_hits"],
        "cache_hits": metrics["cache_hits"],
        "avg_response_time": f"{avg_response:.4f} segundos"
    }
